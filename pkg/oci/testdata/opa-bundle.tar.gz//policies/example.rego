package compliance_framework.example

import rego.v1

violation contains {"remarks": "user not allowed"} if {
	not input.user in data.allowed_users
}
